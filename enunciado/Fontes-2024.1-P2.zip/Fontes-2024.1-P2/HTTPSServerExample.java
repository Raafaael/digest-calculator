import java.io.*;
import java.net.*;
import javax.net.ssl.*;
//
// Servidor HTTPS para ilustrar a utilizacao do SSLServerSocketFactory e SSLServerSocket
public class HTTPSServerExample {
  public static void main(String[] args) throws IOException {
    //
    // verifica args e recebe o caminho e a passphrase do keystore
    if (args.length != 2) {
      System.err.println("Usage: java HTTPSServerExample keystore_path keystore_passphrase");
      System.exit(1);
    }
    String keystore_path = args[0];
    String keystore_passphrase = args[1];
    //
    // Configura as propriedades do keystore
    System.setProperty("javax.net.ssl.keyStore", keystore_path);
    System.setProperty("javax.net.ssl.keyStorePassword", keystore_passphrase);
    //
    // cria um SSL socket usando a factory e alocando a porta 8080
    SSLServerSocketFactory sslsf =
      (SSLServerSocketFactory)SSLServerSocketFactory.getDefault();
    SSLServerSocket sslss = (SSLServerSocket)sslsf.createServerSocket(8080);
    //
    // loop infinito
    while (true) {
      try {
        //
        // lista as cifras habilitadas para o handshake
        System.out.println("Listing default cipher suites for handshake...");
        String[] ciphers = sslss.getEnabledCipherSuites();
        for (int i = 0; i < ciphers.length; ++i)
            System.out.println(ciphers[i]);
	    //
        // restringe as cifras para o handshake
        System.out.println("Restricting ciphers available for handshake...");
        ciphers = new String[] { 	"TLS_AES_128_GCM_SHA256",
        				"TLS_AES_256_GCM_SHA384",
        				"TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384",
        				"TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256",
        				"TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384" };
        sslss.setEnabledCipherSuites(ciphers);
        //
        // lista as cifras habilitadas para o handshake
        System.out.println("Listing cipher suites setting for handshake...");
        ciphers = sslss.getEnabledCipherSuites();
        for (int i = 0; i < ciphers.length; ++i)
        	System.out.println(ciphers[i]);
        //
        // lista os protocolos habilitadas para o handshake
        System.out.println("Listing default protocols for handshake...");
        String[] protocols = sslss.getEnabledProtocols();
        for (int i = 0; i < protocols.length; ++i)
        	System.out.println(protocols[i]);
        //
        // restringe os protocolos para TLS1.2 e TLS1.3
        System.out.println("Restricting protocols to TLS v1.2 e v1.3...");
        protocols = new String[] { "TLSv1.2", "TLSv1.3" };
        sslss.setEnabledProtocols(protocols);
        //
        // lista os protocolos habilitadas para o handshake
        System.out.println("Listing protocol settings for handshake......");
        protocols = sslss.getEnabledProtocols();
        for (int i = 0; i < protocols.length; ++i)
        	System.out.println(protocols[i]);
        //
        // bloqueia aguardando a conexao do cliente
        System.out.println( "Accepting requests..." );
		Socket s = sslss.accept();
        System.out.println( "Client connection made..." );
        // recebe a equisicao do cliente
		System.out.println( "Reading from socket..." );
        BufferedReader in = new BufferedReader(
          new InputStreamReader(s.getInputStream()));
        System.out.println(in.readLine());
        //
        // cria uma resposta no formato HTML
		System.out.println( "Sending Hello HTML..." );
        PrintWriter out = new PrintWriter( s.getOutputStream() );
        out.println("HTTP/1.1 200 OK");
		out.println("Content-Type: text/html; chaset=utf-8");
		out.println("");
		out.println("<HTML><HEAD><TITLE>HTTPS Server Example</TITLE>" +
                    "</HEAD><BODY><H1>Hello World!</H1></BODY></HTML>");
        //
        // fecha o stream e o socket
		System.out.println( "Closing socket..." );
        out.close();
        s.close();
      } catch (Exception e) {
          e.printStackTrace();
      }
    }
  }
}
